# CLIP Image-Text Retrieval API

Production-ready deployment of CLIP-based semantic image search with FastAPI and Redis caching.

## 🚀 Features

- **FastAPI Backend**: High-performance async API for image-text retrieval
- **Redis Caching**: Sub-500ms query latency through intelligent caching
- **Docker Deployment**: Containerized for horizontal scaling
- **Precomputed Embeddings**: Batch inference for 8,000+ images
- **Multiple Endpoints**: Search, embed images, embed text

## 📊 Performance

| Metric | Value |
|--------|-------|
| Query Latency (P95) | <500ms |
| Cached Query Latency | <50ms |
| Embedding Dimension | 256 |
| Supported Images | 8,000+ |

## 🏗️ Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│                 │     │                 │     │                 │
│   Client/UI     │────▶│   FastAPI       │────▶│   CLIP Model    │
│                 │     │   (Uvicorn)     │     │   (PyTorch)     │
│                 │     │                 │     │                 │
└─────────────────┘     └────────┬────────┘     └─────────────────┘
                                 │
                                 ▼
                        ┌─────────────────┐
                        │                 │
                        │   Redis Cache   │
                        │   (Embeddings)  │
                        │                 │
                        └─────────────────┘
```

## 🛠️ Quick Start

### Prerequisites

- Docker & Docker Compose
- Trained model weights (`best_model.pt`)
- Flickr8k dataset (or your own images)

### 1. Clone and Setup

```bash
git clone https://github.com/shrutipangare/clip-image-text-retrieval.git
cd clip-image-text-retrieval
```

### 2. Prepare Model Weights

```bash
mkdir -p weights embeddings
# Copy your trained model weights
cp /path/to/best_model.pt weights/
```

### 3. Precompute Embeddings

```bash
python scripts/precompute_embeddings.py \
    --model weights/best_model.pt \
    --images /path/to/flickr8k/images \
    --captions /path/to/captions.csv \
    --output embeddings \
    --benchmark
```

### 4. Launch with Docker

```bash
docker-compose up -d
```

### 5. Test the API

```bash
# Health check
curl http://localhost:8000/health

# Search for images
curl -X POST http://localhost:8000/search \
    -H "Content-Type: application/json" \
    -d '{"query": "a dog playing in the park", "top_k": 5}'
```

## 📡 API Endpoints

### `GET /health`
Health check endpoint.

### `POST /search`
Search images using natural language.

**Request:**
```json
{
    "query": "a dog playing in the park",
    "top_k": 9
}
```

**Response:**
```json
{
    "query": "a dog playing in the park",
    "results": [
        {"filename": "dog_001.jpg", "similarity": 0.89, "rank": 1},
        {"filename": "park_042.jpg", "similarity": 0.85, "rank": 2}
    ],
    "latency_ms": 47.3,
    "cache_hit": false
}
```

### `POST /embed/image`
Generate embedding for uploaded image.

### `POST /embed/text`
Generate embedding for text query.

## 🔧 Configuration

Environment variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `MODEL_WEIGHTS` | `weights/best_model.pt` | Path to model weights |
| `EMBEDDINGS_PATH` | `embeddings/image_embeddings.npy` | Precomputed embeddings |
| `FILENAMES_PATH` | `embeddings/image_filenames.npy` | Image filename mapping |
| `REDIS_URL` | `redis://localhost:6379` | Redis connection URL |

## 📈 Benchmarking

Run latency benchmarks:

```bash
python scripts/precompute_embeddings.py \
    --model weights/best_model.pt \
    --images /path/to/images \
    --captions /path/to/captions.csv \
    --benchmark
```

Expected output:
```
=== Latency Benchmark Results ===
Mean latency:   127.45 ms
Median latency: 118.32 ms
P95 latency:    245.67 ms
P99 latency:    387.21 ms

✓ P95 latency is under 500ms target!
```

## 🐳 Production Deployment

### Kubernetes (example)

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: clip-api
spec:
  replicas: 3
  selector:
    matchLabels:
      app: clip-api
  template:
    spec:
      containers:
      - name: clip-api
        image: clip-retrieval:latest
        ports:
        - containerPort: 8000
        resources:
          limits:
            memory: "4Gi"
            nvidia.com/gpu: 1
```

### Horizontal Scaling

The API is stateless—scale horizontally behind a load balancer:

```bash
docker-compose up -d --scale api=3
```

## 🔗 Related

- [Training Notebook](clip-text-image.ipynb) - Model training code
- [CLIP Paper](https://arxiv.org/abs/2103.00020) - Original research

## 📄 License

MIT
