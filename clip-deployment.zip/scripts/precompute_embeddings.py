"""
Precompute image embeddings for fast inference
Run this after training to generate embedding cache
"""

import torch
import numpy as np
import pandas as pd
from pathlib import Path
from tqdm import tqdm
import argparse
import os

from app.model import CLIPModel, Config


def precompute_embeddings(
    model_path: str,
    image_dir: str,
    captions_file: str,
    output_dir: str,
    batch_size: int = 32
):
    """
    Precompute and save image embeddings for the entire dataset.
    
    Args:
        model_path: Path to trained model weights
        image_dir: Directory containing images
        captions_file: Path to captions CSV (Flickr8k format)
        output_dir: Directory to save embeddings
        batch_size: Batch size for inference
    """
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    
    # Load model
    print("Loading model...")
    model = CLIPModel().to(device)
    model.load_state_dict(torch.load(model_path, map_location=device))
    model.eval()
    
    # Load image list
    print("Loading image list...")
    df = pd.read_csv(captions_file)
    # Get unique images (each image has 5 captions)
    unique_images = df['image'].unique()
    print(f"Found {len(unique_images)} unique images")
    
    # Compute embeddings
    print("Computing embeddings...")
    all_embeddings = []
    valid_filenames = []
    
    from PIL import Image
    import torch.nn.functional as F
    
    for i in tqdm(range(0, len(unique_images), batch_size)):
        batch_filenames = unique_images[i:i + batch_size]
        images = []
        filenames = []
        
        for filename in batch_filenames:
            img_path = os.path.join(image_dir, filename)
            if os.path.exists(img_path):
                try:
                    img = Image.open(img_path).convert("RGB")
                    images.append(img)
                    filenames.append(filename)
                except Exception as e:
                    print(f"Error loading {filename}: {e}")
        
        if images:
            with torch.no_grad():
                embeddings = model.encode_image(images)
                embeddings = F.normalize(embeddings, dim=-1)
                all_embeddings.append(embeddings.cpu().numpy())
                valid_filenames.extend(filenames)
    
    # Concatenate and save
    all_embeddings = np.concatenate(all_embeddings, axis=0)
    valid_filenames = np.array(valid_filenames)
    
    os.makedirs(output_dir, exist_ok=True)
    
    embeddings_path = os.path.join(output_dir, "image_embeddings.npy")
    filenames_path = os.path.join(output_dir, "image_filenames.npy")
    
    np.save(embeddings_path, all_embeddings)
    np.save(filenames_path, valid_filenames)
    
    print(f"Saved {len(valid_filenames)} embeddings to {output_dir}")
    print(f"  - Embeddings shape: {all_embeddings.shape}")
    print(f"  - Embedding dimension: {all_embeddings.shape[1]}")


def benchmark_latency(
    model_path: str,
    embeddings_path: str,
    num_queries: int = 100
):
    """
    Benchmark query latency to verify <500ms target.
    """
    import time
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    # Load model
    model = CLIPModel().to(device)
    model.load_state_dict(torch.load(model_path, map_location=device))
    model.eval()
    
    # Load embeddings
    image_embeddings = torch.tensor(np.load(embeddings_path)).to(device)
    
    # Sample queries
    queries = [
        "a dog playing in the park",
        "people walking on the beach",
        "a child riding a bicycle",
        "sunset over the mountains",
        "a group of friends laughing",
    ] * (num_queries // 5)
    
    latencies = []
    
    print(f"Benchmarking {num_queries} queries...")
    
    for query in tqdm(queries):
        start = time.time()
        
        with torch.no_grad():
            query_embedding = model.encode_text([query])
            query_embedding = torch.nn.functional.normalize(query_embedding, dim=-1)
            similarities = (query_embedding @ image_embeddings.T).squeeze(0)
            top_k = similarities.argsort(descending=True)[:9]
        
        latency = (time.time() - start) * 1000
        latencies.append(latency)
    
    latencies = np.array(latencies)
    
    print("\n=== Latency Benchmark Results ===")
    print(f"Mean latency:   {latencies.mean():.2f} ms")
    print(f"Median latency: {np.median(latencies):.2f} ms")
    print(f"P95 latency:    {np.percentile(latencies, 95):.2f} ms")
    print(f"P99 latency:    {np.percentile(latencies, 99):.2f} ms")
    print(f"Min latency:    {latencies.min():.2f} ms")
    print(f"Max latency:    {latencies.max():.2f} ms")
    
    if np.percentile(latencies, 95) < 500:
        print("\n✓ P95 latency is under 500ms target!")
    else:
        print("\n✗ P95 latency exceeds 500ms target")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Precompute CLIP embeddings")
    parser.add_argument("--model", type=str, required=True, help="Path to model weights")
    parser.add_argument("--images", type=str, required=True, help="Path to image directory")
    parser.add_argument("--captions", type=str, required=True, help="Path to captions CSV")
    parser.add_argument("--output", type=str, default="embeddings", help="Output directory")
    parser.add_argument("--batch-size", type=int, default=32, help="Batch size")
    parser.add_argument("--benchmark", action="store_true", help="Run latency benchmark after")
    
    args = parser.parse_args()
    
    precompute_embeddings(
        model_path=args.model,
        image_dir=args.images,
        captions_file=args.captions,
        output_dir=args.output,
        batch_size=args.batch_size
    )
    
    if args.benchmark:
        embeddings_path = os.path.join(args.output, "image_embeddings.npy")
        benchmark_latency(args.model, embeddings_path)
