"""
Redis-based caching for CLIP embeddings and search results
Provides low-latency retrieval for repeated queries
"""

import redis
import json
import hashlib
import os
from typing import Optional, List, Any
import pickle


class EmbeddingCache:
    """
    Redis cache for query results and embeddings.
    Falls back to in-memory LRU cache if Redis unavailable.
    """
    
    def __init__(
        self,
        redis_url: Optional[str] = None,
        ttl_seconds: int = 3600,  # 1 hour default
        max_memory_items: int = 1000
    ):
        self.ttl = ttl_seconds
        self.redis_client = None
        self.memory_cache = {}  # Fallback
        self.max_memory_items = max_memory_items
        
        # Try to connect to Redis
        redis_url = redis_url or os.getenv("REDIS_URL", "redis://localhost:6379")
        try:
            self.redis_client = redis.from_url(redis_url, decode_responses=False)
            self.redis_client.ping()
            print(f"Connected to Redis at {redis_url}")
        except (redis.ConnectionError, redis.RedisError) as e:
            print(f"Redis unavailable ({e}), using in-memory cache")
            self.redis_client = None
    
    def _hash_key(self, key: str) -> str:
        """Create consistent hash for cache keys"""
        return f"clip:{hashlib.md5(key.encode()).hexdigest()}"
    
    def get(self, key: str) -> Optional[Any]:
        """Retrieve cached value"""
        hashed_key = self._hash_key(key)
        
        if self.redis_client:
            try:
                data = self.redis_client.get(hashed_key)
                if data:
                    return pickle.loads(data)
            except redis.RedisError:
                pass
        
        # Fallback to memory cache
        return self.memory_cache.get(hashed_key)
    
    def set(self, key: str, value: Any) -> bool:
        """Store value in cache"""
        hashed_key = self._hash_key(key)
        
        if self.redis_client:
            try:
                self.redis_client.setex(
                    hashed_key,
                    self.ttl,
                    pickle.dumps(value)
                )
                return True
            except redis.RedisError:
                pass
        
        # Fallback to memory cache with simple LRU
        if len(self.memory_cache) >= self.max_memory_items:
            # Remove oldest item (simple FIFO, not true LRU)
            oldest_key = next(iter(self.memory_cache))
            del self.memory_cache[oldest_key]
        
        self.memory_cache[hashed_key] = value
        return True
    
    def delete(self, key: str) -> bool:
        """Remove value from cache"""
        hashed_key = self._hash_key(key)
        
        if self.redis_client:
            try:
                self.redis_client.delete(hashed_key)
            except redis.RedisError:
                pass
        
        if hashed_key in self.memory_cache:
            del self.memory_cache[hashed_key]
        
        return True
    
    def clear(self) -> bool:
        """Clear all cached values"""
        if self.redis_client:
            try:
                # Only clear keys with our prefix
                for key in self.redis_client.scan_iter("clip:*"):
                    self.redis_client.delete(key)
            except redis.RedisError:
                pass
        
        self.memory_cache.clear()
        return True
    
    def stats(self) -> dict:
        """Get cache statistics"""
        stats = {
            "backend": "redis" if self.redis_client else "memory",
            "memory_items": len(self.memory_cache)
        }
        
        if self.redis_client:
            try:
                info = self.redis_client.info("memory")
                stats["redis_memory_used"] = info.get("used_memory_human", "unknown")
                stats["redis_keys"] = self.redis_client.dbsize()
            except redis.RedisError:
                stats["redis_status"] = "error"
        
        return stats


class EmbeddingStore:
    """
    Persistent storage for precomputed image embeddings.
    Uses Redis for fast retrieval in production.
    """
    
    def __init__(self, redis_url: Optional[str] = None):
        self.redis_client = None
        redis_url = redis_url or os.getenv("REDIS_URL", "redis://localhost:6379")
        
        try:
            self.redis_client = redis.from_url(redis_url, decode_responses=False)
            self.redis_client.ping()
        except (redis.ConnectionError, redis.RedisError):
            self.redis_client = None
    
    def store_embedding(self, image_id: str, embedding: List[float]) -> bool:
        """Store single image embedding"""
        if not self.redis_client:
            return False
        
        try:
            key = f"emb:{image_id}"
            self.redis_client.set(key, pickle.dumps(embedding))
            return True
        except redis.RedisError:
            return False
    
    def get_embedding(self, image_id: str) -> Optional[List[float]]:
        """Retrieve single image embedding"""
        if not self.redis_client:
            return None
        
        try:
            key = f"emb:{image_id}"
            data = self.redis_client.get(key)
            if data:
                return pickle.loads(data)
        except redis.RedisError:
            pass
        
        return None
    
    def bulk_store(self, embeddings: dict) -> int:
        """Store multiple embeddings at once"""
        if not self.redis_client:
            return 0
        
        stored = 0
        pipe = self.redis_client.pipeline()
        
        try:
            for image_id, embedding in embeddings.items():
                key = f"emb:{image_id}"
                pipe.set(key, pickle.dumps(embedding))
                stored += 1
            
            pipe.execute()
        except redis.RedisError:
            pass
        
        return stored
