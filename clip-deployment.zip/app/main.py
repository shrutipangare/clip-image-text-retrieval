"""
CLIP Image-Text Retrieval API
FastAPI backend for semantic image search using natural language queries
"""

from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import torch
import numpy as np
from PIL import Image
import io
import os
from contextlib import asynccontextmanager

from model import CLIPModel, get_image_embeddings
from cache import EmbeddingCache

# Initialize cache
cache = EmbeddingCache()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Load model and embeddings on startup"""
    global model, image_embeddings, image_filenames, device
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    
    # Load model
    model = CLIPModel().to(device)
    weights_path = os.getenv("MODEL_WEIGHTS", "weights/best_model.pt")
    if os.path.exists(weights_path):
        model.load_state_dict(torch.load(weights_path, map_location=device))
    model.eval()
    
    # Load precomputed embeddings if available
    embeddings_path = os.getenv("EMBEDDINGS_PATH", "embeddings/image_embeddings.npy")
    filenames_path = os.getenv("FILENAMES_PATH", "embeddings/image_filenames.npy")
    
    if os.path.exists(embeddings_path) and os.path.exists(filenames_path):
        image_embeddings = torch.tensor(np.load(embeddings_path)).to(device)
        image_filenames = np.load(filenames_path, allow_pickle=True)
        print(f"Loaded {len(image_filenames)} precomputed embeddings")
    else:
        image_embeddings = None
        image_filenames = None
        print("No precomputed embeddings found - will compute on demand")
    
    yield
    
    # Cleanup
    print("Shutting down...")


app = FastAPI(
    title="CLIP Image-Text Retrieval API",
    description="Semantic image search using natural language queries",
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class SearchRequest(BaseModel):
    query: str
    top_k: int = 9
    
class SearchResult(BaseModel):
    filename: str
    similarity: float
    rank: int

class SearchResponse(BaseModel):
    query: str
    results: List[SearchResult]
    latency_ms: float
    cache_hit: bool


@app.get("/health")
async def health_check():
    return {"status": "healthy", "model_loaded": model is not None}


@app.post("/search", response_model=SearchResponse)
async def search_images(request: SearchRequest):
    """
    Search for images using natural language query.
    Returns top-k most similar images based on cosine similarity.
    """
    import time
    start_time = time.time()
    
    if image_embeddings is None:
        raise HTTPException(
            status_code=503, 
            detail="Image embeddings not loaded. Please precompute embeddings first."
        )
    
    # Check cache first
    cache_key = f"query:{request.query}"
    cached_result = cache.get(cache_key)
    
    if cached_result is not None:
        latency_ms = (time.time() - start_time) * 1000
        return SearchResponse(
            query=request.query,
            results=cached_result[:request.top_k],
            latency_ms=latency_ms,
            cache_hit=True
        )
    
    # Encode query
    with torch.no_grad():
        query_embedding = model.encode_text([request.query])
        query_embedding = torch.nn.functional.normalize(query_embedding, dim=-1)
    
    # Compute similarities
    similarities = (query_embedding @ image_embeddings.T).squeeze(0)
    
    # Get top-k results
    top_k_indices = similarities.argsort(descending=True)[:request.top_k]
    
    results = []
    for rank, idx in enumerate(top_k_indices):
        results.append(SearchResult(
            filename=str(image_filenames[idx]),
            similarity=float(similarities[idx]),
            rank=rank + 1
        ))
    
    # Cache results
    cache.set(cache_key, results)
    
    latency_ms = (time.time() - start_time) * 1000
    
    return SearchResponse(
        query=request.query,
        results=results,
        latency_ms=latency_ms,
        cache_hit=False
    )


@app.post("/embed/image")
async def embed_image(file: UploadFile = File(...)):
    """Generate embedding for a single uploaded image"""
    import time
    start_time = time.time()
    
    # Read and process image
    contents = await file.read()
    image = Image.open(io.BytesIO(contents)).convert("RGB")
    
    with torch.no_grad():
        embedding = model.encode_image([image])
        embedding = torch.nn.functional.normalize(embedding, dim=-1)
    
    latency_ms = (time.time() - start_time) * 1000
    
    return {
        "filename": file.filename,
        "embedding": embedding.cpu().numpy().tolist(),
        "embedding_dim": embedding.shape[-1],
        "latency_ms": latency_ms
    }


@app.post("/embed/text")
async def embed_text(text: str):
    """Generate embedding for text query"""
    import time
    start_time = time.time()
    
    with torch.no_grad():
        embedding = model.encode_text([text])
        embedding = torch.nn.functional.normalize(embedding, dim=-1)
    
    latency_ms = (time.time() - start_time) * 1000
    
    return {
        "text": text,
        "embedding": embedding.cpu().numpy().tolist(),
        "embedding_dim": embedding.shape[-1],
        "latency_ms": latency_ms
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
