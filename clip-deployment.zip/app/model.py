"""
CLIP Model Architecture
Matches the notebook implementation for weight compatibility
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import DistilBertModel, DistilBertTokenizer, BertModel, BertTokenizer, RobertaModel, RobertaTokenizer
import timm
from typing import List, Optional
from PIL import Image
import albumentations as A
from albumentations.pytorch import ToTensorV2
import numpy as np


class Config:
    """Model configuration - matches notebook"""
    image_encoder = "resnet50"  # resnet18, resnet34, resnet50
    text_encoder = "roberta-base"  # distilbert-base-uncased, bert-base-uncased, roberta-base
    image_embedding = 2048  # 512 for resnet18/34, 2048 for resnet50
    text_embedding = 768
    projection_dim = 256
    temperature = 1.0
    max_length = 200
    image_size = 224
    pretrained = True
    trainable = True


class ImageEncoder(nn.Module):
    """ResNet-based image encoder"""
    
    def __init__(
        self,
        model_name: str = Config.image_encoder,
        pretrained: bool = Config.pretrained,
        trainable: bool = Config.trainable
    ):
        super().__init__()
        self.model = timm.create_model(
            model_name, 
            pretrained=pretrained, 
            num_classes=0,  # Remove classification head
            global_pool="avg"
        )
        
        for param in self.model.parameters():
            param.requires_grad = trainable
    
    def forward(self, x):
        return self.model(x)


class TextEncoder(nn.Module):
    """Transformer-based text encoder"""
    
    def __init__(
        self,
        model_name: str = Config.text_encoder,
        trainable: bool = Config.trainable
    ):
        super().__init__()
        
        if "distilbert" in model_name:
            self.model = DistilBertModel.from_pretrained(model_name)
        elif "roberta" in model_name:
            self.model = RobertaModel.from_pretrained(model_name)
        else:
            self.model = BertModel.from_pretrained(model_name)
        
        for param in self.model.parameters():
            param.requires_grad = trainable
        
        self.target_token_idx = 0  # CLS token
    
    def forward(self, input_ids, attention_mask):
        output = self.model(input_ids=input_ids, attention_mask=attention_mask)
        last_hidden_state = output.last_hidden_state
        return last_hidden_state[:, self.target_token_idx, :]


class ProjectionHead(nn.Module):
    """Projects embeddings to shared space"""
    
    def __init__(
        self,
        embedding_dim: int,
        projection_dim: int = Config.projection_dim,
        dropout: float = 0.1
    ):
        super().__init__()
        self.projection = nn.Linear(embedding_dim, projection_dim)
        self.gelu = nn.GELU()
        self.fc = nn.Linear(projection_dim, projection_dim)
        self.dropout = nn.Dropout(dropout)
        self.layer_norm = nn.LayerNorm(projection_dim)
    
    def forward(self, x):
        projected = self.projection(x)
        x = self.gelu(projected)
        x = self.fc(x)
        x = self.dropout(x)
        x = x + projected
        x = self.layer_norm(x)
        return x


class CLIPModel(nn.Module):
    """
    Full CLIP model combining image and text encoders
    """
    
    def __init__(
        self,
        temperature: float = Config.temperature,
        image_embedding: int = Config.image_embedding,
        text_embedding: int = Config.text_embedding,
        projection_dim: int = Config.projection_dim
    ):
        super().__init__()
        self.image_encoder = ImageEncoder()
        self.text_encoder = TextEncoder()
        self.image_projection = ProjectionHead(image_embedding, projection_dim)
        self.text_projection = ProjectionHead(text_embedding, projection_dim)
        self.temperature = temperature
        
        # Initialize tokenizer
        if "distilbert" in Config.text_encoder:
            self.tokenizer = DistilBertTokenizer.from_pretrained(Config.text_encoder)
        elif "roberta" in Config.text_encoder:
            self.tokenizer = RobertaTokenizer.from_pretrained(Config.text_encoder)
        else:
            self.tokenizer = BertTokenizer.from_pretrained(Config.text_encoder)
        
        # Image transforms
        self.image_transform = A.Compose([
            A.Resize(Config.image_size, Config.image_size, always_apply=True),
            A.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5], always_apply=True),
            ToTensorV2()
        ])
    
    def encode_image(self, images: List[Image.Image]) -> torch.Tensor:
        """Encode PIL images to embeddings"""
        device = next(self.parameters()).device
        
        # Transform images
        tensors = []
        for img in images:
            img_array = np.array(img)
            transformed = self.image_transform(image=img_array)
            tensors.append(transformed["image"])
        
        batch = torch.stack(tensors).to(device)
        
        # Encode
        features = self.image_encoder(batch)
        embeddings = self.image_projection(features)
        return embeddings
    
    def encode_text(self, texts: List[str]) -> torch.Tensor:
        """Encode text strings to embeddings"""
        device = next(self.parameters()).device
        
        # Tokenize
        encoded = self.tokenizer(
            texts,
            padding=True,
            truncation=True,
            max_length=Config.max_length,
            return_tensors="pt"
        )
        
        input_ids = encoded["input_ids"].to(device)
        attention_mask = encoded["attention_mask"].to(device)
        
        # Encode
        features = self.text_encoder(input_ids, attention_mask)
        embeddings = self.text_projection(features)
        return embeddings
    
    def forward(self, batch):
        """Forward pass for training"""
        # Get image features
        image_features = self.image_encoder(batch["image"])
        image_embeddings = self.image_projection(image_features)
        
        # Get text features
        text_features = self.text_encoder(
            batch["input_ids"], 
            batch["attention_mask"]
        )
        text_embeddings = self.text_projection(text_features)
        
        # Compute similarity
        logits = (text_embeddings @ image_embeddings.T) / self.temperature
        
        # Symmetric loss
        images_similarity = image_embeddings @ image_embeddings.T
        texts_similarity = text_embeddings @ text_embeddings.T
        targets = F.softmax(
            (images_similarity + texts_similarity) / 2 * self.temperature,
            dim=-1
        )
        
        texts_loss = F.cross_entropy(logits, targets, reduction='none')
        images_loss = F.cross_entropy(logits.T, targets.T, reduction='none')
        loss = (images_loss + texts_loss) / 2.0
        
        return loss.mean()


def get_image_embeddings(model: CLIPModel, image_paths: List[str], batch_size: int = 32) -> torch.Tensor:
    """Compute embeddings for a list of image paths"""
    model.eval()
    device = next(model.parameters()).device
    all_embeddings = []
    
    for i in range(0, len(image_paths), batch_size):
        batch_paths = image_paths[i:i + batch_size]
        images = [Image.open(p).convert("RGB") for p in batch_paths]
        
        with torch.no_grad():
            embeddings = model.encode_image(images)
            embeddings = F.normalize(embeddings, dim=-1)
            all_embeddings.append(embeddings.cpu())
    
    return torch.cat(all_embeddings, dim=0)
